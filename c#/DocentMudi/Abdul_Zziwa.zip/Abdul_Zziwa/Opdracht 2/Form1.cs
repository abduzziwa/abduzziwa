﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Opdracht_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CleanBtn_Click(object sender, EventArgs e)
        {
            roepnaamTxtBx.Text = "";
            achternaamTxtBx.Text = "";
            leeftijdTxtBx.Text = "";
            label1.Text = "";
            label2.Text = "";


        }

        private void RunBtn_Click(object sender, EventArgs e)
        {
            try
            {
                String roepnaam = roepnaamTxtBx.Text;
                String achternaam = achternaamTxtBx.Text;
                int leeftijd = Convert.ToInt32(leeftijdTxtBx.Text);

                label1.Text = roepnaam + " " + achternaam + " " + leeftijd;

                if(leeftijd >= 18)
                {
                    label2.Text = "Drink bier in plaats van water, dan heb je morgen een flinke kater";
                } else
                {
                    label2.Text = "Je mag nog geen alcohol drinken.";

                }

            }
            catch (Exception ex) {
                label2.Text = ex.Message;            
            }
        }
    }
}
