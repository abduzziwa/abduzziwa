﻿namespace Opdracht_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Heading = new System.Windows.Forms.Label();
            this.roepnaamlbl = new System.Windows.Forms.Label();
            this.Leeftijdlbl = new System.Windows.Forms.Label();
            this.achternaamlbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.RunBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.CleanBtn = new System.Windows.Forms.Button();
            this.roepnaamTxtBx = new System.Windows.Forms.TextBox();
            this.leeftijdTxtBx = new System.Windows.Forms.TextBox();
            this.achternaamTxtBx = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Heading
            // 
            this.Heading.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Heading.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Heading.Location = new System.Drawing.Point(312, 20);
            this.Heading.Name = "Heading";
            this.Heading.Size = new System.Drawing.Size(159, 37);
            this.Heading.TabIndex = 0;
            this.Heading.Text = "Opdracht 2";
            // 
            // roepnaamlbl
            // 
            this.roepnaamlbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.roepnaamlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roepnaamlbl.Location = new System.Drawing.Point(32, 77);
            this.roepnaamlbl.Name = "roepnaamlbl";
            this.roepnaamlbl.Size = new System.Drawing.Size(141, 28);
            this.roepnaamlbl.TabIndex = 1;
            this.roepnaamlbl.Text = "Roepnaam";
            // 
            // Leeftijdlbl
            // 
            this.Leeftijdlbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Leeftijdlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Leeftijdlbl.Location = new System.Drawing.Point(32, 169);
            this.Leeftijdlbl.Name = "Leeftijdlbl";
            this.Leeftijdlbl.Size = new System.Drawing.Size(141, 28);
            this.Leeftijdlbl.TabIndex = 2;
            this.Leeftijdlbl.Text = "Leeftijd";
            // 
            // achternaamlbl
            // 
            this.achternaamlbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.achternaamlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.achternaamlbl.Location = new System.Drawing.Point(32, 120);
            this.achternaamlbl.Name = "achternaamlbl";
            this.achternaamlbl.Size = new System.Drawing.Size(141, 28);
            this.achternaamlbl.TabIndex = 3;
            this.achternaamlbl.Text = "Achternaam";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(630, 28);
            this.label1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(630, 92);
            this.label2.TabIndex = 5;
            // 
            // RunBtn
            // 
            this.RunBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunBtn.Location = new System.Drawing.Point(246, 459);
            this.RunBtn.Name = "RunBtn";
            this.RunBtn.Size = new System.Drawing.Size(116, 38);
            this.RunBtn.TabIndex = 6;
            this.RunBtn.Text = "Run";
            this.RunBtn.UseVisualStyleBackColor = true;
            this.RunBtn.Click += new System.EventHandler(this.RunBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.Location = new System.Drawing.Point(554, 459);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(116, 38);
            this.ExitBtn.TabIndex = 7;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // CleanBtn
            // 
            this.CleanBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CleanBtn.Location = new System.Drawing.Point(397, 459);
            this.CleanBtn.Name = "CleanBtn";
            this.CleanBtn.Size = new System.Drawing.Size(116, 38);
            this.CleanBtn.TabIndex = 8;
            this.CleanBtn.Text = "Clean";
            this.CleanBtn.UseVisualStyleBackColor = true;
            this.CleanBtn.Click += new System.EventHandler(this.CleanBtn_Click);
            // 
            // roepnaamTxtBx
            // 
            this.roepnaamTxtBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roepnaamTxtBx.Location = new System.Drawing.Point(189, 77);
            this.roepnaamTxtBx.Name = "roepnaamTxtBx";
            this.roepnaamTxtBx.Size = new System.Drawing.Size(455, 26);
            this.roepnaamTxtBx.TabIndex = 9;
            // 
            // leeftijdTxtBx
            // 
            this.leeftijdTxtBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leeftijdTxtBx.Location = new System.Drawing.Point(189, 171);
            this.leeftijdTxtBx.Name = "leeftijdTxtBx";
            this.leeftijdTxtBx.Size = new System.Drawing.Size(455, 26);
            this.leeftijdTxtBx.TabIndex = 10;
            // 
            // achternaamTxtBx
            // 
            this.achternaamTxtBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.achternaamTxtBx.Location = new System.Drawing.Point(189, 122);
            this.achternaamTxtBx.Name = "achternaamTxtBx";
            this.achternaamTxtBx.Size = new System.Drawing.Size(455, 26);
            this.achternaamTxtBx.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 545);
            this.Controls.Add(this.achternaamTxtBx);
            this.Controls.Add(this.leeftijdTxtBx);
            this.Controls.Add(this.roepnaamTxtBx);
            this.Controls.Add(this.CleanBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.RunBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.achternaamlbl);
            this.Controls.Add(this.Leeftijdlbl);
            this.Controls.Add(this.roepnaamlbl);
            this.Controls.Add(this.Heading);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Heading;
        private System.Windows.Forms.Label roepnaamlbl;
        private System.Windows.Forms.Label Leeftijdlbl;
        private System.Windows.Forms.Label achternaamlbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button RunBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button CleanBtn;
        private System.Windows.Forms.TextBox roepnaamTxtBx;
        private System.Windows.Forms.TextBox leeftijdTxtBx;
        private System.Windows.Forms.TextBox achternaamTxtBx;
    }
}

