﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Opdracht_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CleanBtn_Click(object sender, EventArgs e)
        {
            Outputlbl.Text = "";
            textbox1.Text = "";
            textbox2.Text = "";
            OperatorTxtBx.Text = "";
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RunBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double getal1 = Convert.ToDouble(textbox1.Text);
                string Operator = OperatorTxtBx.Text;
                double getal2 = Convert.ToDouble(textbox2.Text);
                double output;

                switch (Operator)
                {
                    case "+":
                        output = getal1 + getal2;
                        Outputlbl.Text = output.ToString();
                        break;
                    case "-":
                        output = getal1 - getal2;
                        Outputlbl.Text = output.ToString();
                        break;
                    case "*":
                        output = getal1 * getal2;
                        Outputlbl.Text = output.ToString();
                        break;
                    case "/":
                        output = getal1 / getal2;
                        Outputlbl.Text = output.ToString();
                        break;
                }

            }
            catch (Exception ex) {
                Outputlbl.Text = "invalid input!!";
            }
        }
    }
}
