﻿namespace Opdracht_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Heading = new System.Windows.Forms.Label();
            this.getal1 = new System.Windows.Forms.Label();
            this.Operator = new System.Windows.Forms.Label();
            this.getal2 = new System.Windows.Forms.Label();
            this.Outputlbl = new System.Windows.Forms.Label();
            this.equal = new System.Windows.Forms.Label();
            this.textbox1 = new System.Windows.Forms.TextBox();
            this.OperatorTxtBx = new System.Windows.Forms.TextBox();
            this.textbox2 = new System.Windows.Forms.TextBox();
            this.RunBtn = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.CleanBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Heading
            // 
            this.Heading.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Heading.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Heading.Location = new System.Drawing.Point(230, 51);
            this.Heading.Name = "Heading";
            this.Heading.Size = new System.Drawing.Size(292, 39);
            this.Heading.TabIndex = 0;
            this.Heading.Text = "Welcome to C# World";
            // 
            // getal1
            // 
            this.getal1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.getal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getal1.Location = new System.Drawing.Point(167, 152);
            this.getal1.Name = "getal1";
            this.getal1.Size = new System.Drawing.Size(160, 28);
            this.getal1.TabIndex = 1;
            this.getal1.Text = "getal 1";
            this.getal1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Operator
            // 
            this.Operator.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Operator.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Operator.Location = new System.Drawing.Point(165, 196);
            this.Operator.Name = "Operator";
            this.Operator.Size = new System.Drawing.Size(162, 28);
            this.Operator.TabIndex = 2;
            this.Operator.Text = "Operator ( +,-,*,/ )";
            this.Operator.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // getal2
            // 
            this.getal2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.getal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getal2.Location = new System.Drawing.Point(163, 240);
            this.getal2.Name = "getal2";
            this.getal2.Size = new System.Drawing.Size(164, 28);
            this.getal2.TabIndex = 3;
            this.getal2.Text = "getal 2";
            this.getal2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Outputlbl
            // 
            this.Outputlbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Outputlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Outputlbl.Location = new System.Drawing.Point(344, 293);
            this.Outputlbl.Name = "Outputlbl";
            this.Outputlbl.Size = new System.Drawing.Size(144, 28);
            this.Outputlbl.TabIndex = 4;
            this.Outputlbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // equal
            // 
            this.equal.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equal.Location = new System.Drawing.Point(296, 293);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(31, 28);
            this.equal.TabIndex = 5;
            this.equal.Text = "=";
            this.equal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textbox1
            // 
            this.textbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox1.Location = new System.Drawing.Point(348, 152);
            this.textbox1.Name = "textbox1";
            this.textbox1.Size = new System.Drawing.Size(100, 26);
            this.textbox1.TabIndex = 6;
            this.textbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OperatorTxtBx
            // 
            this.OperatorTxtBx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OperatorTxtBx.Location = new System.Drawing.Point(348, 196);
            this.OperatorTxtBx.Name = "OperatorTxtBx";
            this.OperatorTxtBx.Size = new System.Drawing.Size(55, 26);
            this.OperatorTxtBx.TabIndex = 7;
            this.OperatorTxtBx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textbox2
            // 
            this.textbox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox2.Location = new System.Drawing.Point(348, 244);
            this.textbox2.Name = "textbox2";
            this.textbox2.Size = new System.Drawing.Size(100, 26);
            this.textbox2.TabIndex = 8;
            this.textbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // RunBtn
            // 
            this.RunBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RunBtn.Location = new System.Drawing.Point(269, 359);
            this.RunBtn.Name = "RunBtn";
            this.RunBtn.Size = new System.Drawing.Size(93, 34);
            this.RunBtn.TabIndex = 9;
            this.RunBtn.Text = "Run";
            this.RunBtn.UseVisualStyleBackColor = true;
            this.RunBtn.Click += new System.EventHandler(this.RunBtn_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.Location = new System.Drawing.Point(529, 359);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(93, 34);
            this.Exitbtn.TabIndex = 10;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // CleanBtn
            // 
            this.CleanBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CleanBtn.Location = new System.Drawing.Point(395, 359);
            this.CleanBtn.Name = "CleanBtn";
            this.CleanBtn.Size = new System.Drawing.Size(93, 34);
            this.CleanBtn.TabIndex = 11;
            this.CleanBtn.Text = "Clean";
            this.CleanBtn.UseVisualStyleBackColor = true;
            this.CleanBtn.Click += new System.EventHandler(this.CleanBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CleanBtn);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.RunBtn);
            this.Controls.Add(this.textbox2);
            this.Controls.Add(this.OperatorTxtBx);
            this.Controls.Add(this.textbox1);
            this.Controls.Add(this.equal);
            this.Controls.Add(this.Outputlbl);
            this.Controls.Add(this.getal2);
            this.Controls.Add(this.Operator);
            this.Controls.Add(this.getal1);
            this.Controls.Add(this.Heading);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Heading;
        private System.Windows.Forms.Label getal1;
        private System.Windows.Forms.Label Operator;
        private System.Windows.Forms.Label getal2;
        private System.Windows.Forms.Label Outputlbl;
        private System.Windows.Forms.Label equal;
        private System.Windows.Forms.TextBox textbox1;
        private System.Windows.Forms.TextBox OperatorTxtBx;
        private System.Windows.Forms.TextBox textbox2;
        private System.Windows.Forms.Button RunBtn;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Button CleanBtn;
    }
}

