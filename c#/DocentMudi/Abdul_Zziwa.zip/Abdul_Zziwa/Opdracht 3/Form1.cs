﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Opdracht_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CleanBtn_Click(object sender, EventArgs e)
        {
            outputlbl.Text = "";
            textbox.Text = "";
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RunBtn_Click(object sender, EventArgs e)
      
        {
            try
            {
    
                int value = Convert.ToInt32(textbox.Text);

                for (int i = 1; i <= 10; i = i + 1)
                {
                    int output = i * value;
                    outputlbl.Text = outputlbl.Text + i.ToString() + " " + "*" + " " + value.ToString() + " " + "=" + " " + output + "\n";
                }
            }
            catch (Exception ex)
            {
                outputlbl.Text = ex.Message;
            }
        }
    }
}
